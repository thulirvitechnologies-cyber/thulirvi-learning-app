-- ==============================================================================
-- THULIRVI LEARN - PRODUCTION DATABASE SCHEMA FOR SUPABASE (FREE TIER)
-- Virtual Internship & Learning Platform - 12 Tracks + Self-Paced Courses
-- ==============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USER PROFILES & ROLES
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    student_id TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    college TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'admin')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

-- 2. VIRTUAL INTERNSHIP TRACKS & COURSES
CREATE TABLE IF NOT EXISTS public.programmes (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN ('internship', 'course')),
    description TEXT NOT NULL,
    duration TEXT NOT NULL,
    prerequisites TEXT NOT NULL,
    fee_amount NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    is_available BOOLEAN NOT NULL DEFAULT true,
    syllabus JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

-- 3. STUDENT REGISTRATION APPLICATIONS & ENROLMENTS
CREATE TABLE IF NOT EXISTS public.enrolments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    programme_id TEXT NOT NULL REFERENCES public.programmes(id) ON DELETE CASCADE,
    batch_name TEXT NOT NULL,
    application_status TEXT NOT NULL DEFAULT 'pending' 
        CHECK (application_status IN ('pending', 'approved', 'rejected', 'more_info_required')),
    payment_status TEXT NOT NULL DEFAULT 'not_required'
        CHECK (payment_status IN ('not_required', 'pending_verification', 'verified')),
    start_date DATE,
    end_date DATE,
    admin_notes TEXT,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
    approved_at TIMESTAMPTZ,
    UNIQUE(student_id, programme_id)
);

-- 4. LESSON COMPLETION TRACKING
CREATE TABLE IF NOT EXISTS public.lesson_completions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    programme_id TEXT NOT NULL REFERENCES public.programmes(id) ON DELETE CASCADE,
    lesson_id TEXT NOT NULL,
    completed_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
    UNIQUE(student_id, lesson_id)
);

-- 5. ASSIGNMENTS & WEEKLY TASKS
CREATE TABLE IF NOT EXISTS public.assignments (
    id TEXT PRIMARY KEY,
    programme_id TEXT NOT NULL REFERENCES public.programmes(id) ON DELETE CASCADE,
    week_number INT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    github_starter_url TEXT,
    rubric TEXT NOT NULL,
    max_score INT NOT NULL DEFAULT 100,
    deadline TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

-- 6. STUDENT SUBMISSIONS & EVALUATIONS
CREATE TABLE IF NOT EXISTS public.submissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    assignment_id TEXT NOT NULL REFERENCES public.assignments(id) ON DELETE CASCADE,
    student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    repo_url TEXT NOT NULL,
    live_demo_url TEXT,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'submitted' 
        CHECK (status IN ('draft', 'submitted', 'under_review', 'revision_requested', 'evaluated')),
    score INT CHECK (score >= 0 AND score <= 100),
    feedback TEXT,
    evaluated_by UUID REFERENCES public.profiles(id),
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
    evaluated_at TIMESTAMPTZ
);

-- 7. OFFICIAL CERTIFICATES (TAMPER-EVIDENT CREDENTIALS)
CREATE TABLE IF NOT EXISTS public.certificates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    credential_id TEXT UNIQUE NOT NULL,
    student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    programme_id TEXT NOT NULL REFERENCES public.programmes(id) ON DELETE CASCADE,
    honors_grade TEXT NOT NULL DEFAULT 'Honors Grade A',
    issue_date DATE NOT NULL DEFAULT CURRENT_DATE,
    verification_url TEXT NOT NULL,
    issued_by_admin UUID NOT NULL REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

-- 8. ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.programmes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enrolments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lesson_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;

-- Helper security function: Check if current caller is an administrator
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND role = 'admin'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Profiles: Students can read their own profile; Admins can read all profiles
CREATE POLICY "Users can read own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id OR public.is_admin());

CREATE POLICY "Users can update own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

-- Programmes: Everyone can browse the catalogue
CREATE POLICY "Public read programmes" ON public.programmes
    FOR SELECT USING (true);

CREATE POLICY "Admins can manage programmes" ON public.programmes
    FOR ALL USING (public.is_admin());

-- Enrolments: Students see own enrolments; Admins manage all
CREATE POLICY "Students see own enrolments" ON public.enrolments
    FOR SELECT USING (student_id = auth.uid() OR public.is_admin());

CREATE POLICY "Students can apply" ON public.enrolments
    FOR INSERT WITH CHECK (student_id = auth.uid());

CREATE POLICY "Admins can update enrolments" ON public.enrolments
    FOR UPDATE USING (public.is_admin());

-- Submissions: Students see and submit their own; Admins evaluate all
CREATE POLICY "Students see own submissions" ON public.submissions
    FOR SELECT USING (student_id = auth.uid() OR public.is_admin());

CREATE POLICY "Students submit own assignments" ON public.submissions
    FOR INSERT WITH CHECK (student_id = auth.uid());

CREATE POLICY "Admins evaluate submissions" ON public.submissions
    FOR UPDATE USING (public.is_admin());

-- Certificates: Public can verify certificates via credential ID
CREATE POLICY "Public can view valid certificates" ON public.certificates
    FOR SELECT USING (true);

CREATE POLICY "Admins issue certificates" ON public.certificates
    FOR INSERT WITH CHECK (public.is_admin());
