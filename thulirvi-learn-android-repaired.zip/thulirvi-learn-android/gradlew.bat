@rem Thulirvi Technologies Gradle Wrapper execution script for Windows
@rem Run assembleRelease to generate production APK
@call gradle "%*"
