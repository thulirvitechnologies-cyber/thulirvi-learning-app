# Thulirvi Learn Proguard Obfuscation Rules
-keep class com.thulirvi.learn.data.model.** { *; }
-keepclassmembers class * implements java.io.Serializable { *; }
-dontwarn okhttp3.**
-dontwarn retrofit2.**
