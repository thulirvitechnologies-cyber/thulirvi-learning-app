package com.thulirvi.learn

import android.app.Application
import com.thulirvi.learn.data.local.ThulirviDatabase
import com.thulirvi.learn.data.repository.ThulirviRepository

/**
 * Thulirvi Technologies Learning & Internship Application Container
 */
class ThulirviApp : Application() {

    val database: ThulirviDatabase by lazy {
        ThulirviDatabase.getDatabase(this)
    }

    val repository: ThulirviRepository by lazy {
        ThulirviRepository(database.thulirviDao())
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: ThulirviApp
            private set
    }
}
