package com.thulirvi.learn.ui.theme

import androidx.compose.ui.graphics.Color

// Thulirvi Technologies Brand Colors (Green to Teal Gradient Spectrum)
val ThulirviPrimaryDark = Color(0xFF0D9488)      // Teal 600
val ThulirviPrimaryLight = Color(0xFF047857)     // Emerald 700
val ThulirviOnPrimary = Color(0xFFFFFFFF)

val ThulirviSecondaryDark = Color(0xFF2DD4BF)    // Teal 400
val ThulirviSecondaryLight = Color(0xFF059669)   // Emerald 600

val ThulirviTertiary = Color(0xFF34D399)         // Emerald 400
val ThulirviBackgroundDark = Color(0xFF081216)   // Deep slate teal
val ThulirviSurfaceDark = Color(0xFF0F1E24)      // Elevated surface
val ThulirviCardBorder = Color(0xFF1B3842)

val ThulirviBackgroundLight = Color(0xFFF8FAFC)
val ThulirviSurfaceLight = Color(0xFFFFFFFF)

val StatusApproved = Color(0xFF10B981)
val StatusPending = Color(0xFFF59E0B)
val StatusChangesRequested = Color(0xFFEF4444)
val StatusUnderReview = Color(0xFF3B82F6)
