package com.thulirvi.learn.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Register : Screen("register")
    object Dashboard : Screen("dashboard")
    object Internships : Screen("internships")
    object InternshipDetail : Screen("internship_detail/{internshipId}") {
        fun createRoute(internshipId: String) = "internship_detail/$internshipId"
    }
    object Assignments : Screen("assignments")
    object SubmitAssignment : Screen("submit_assignment/{assignmentId}") {
        fun createRoute(assignmentId: String) = "submit_assignment/$assignmentId"
    }
    object Certificates : Screen("certificates")
    object AdminPortal : Screen("admin_portal")
    object Announcements : Screen("announcements")
}
