package com.thulirvi.learn.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.thulirvi.learn.data.model.Assignment
import com.thulirvi.learn.data.model.Internship
import com.thulirvi.learn.data.model.Submission
import com.thulirvi.learn.data.model.User

@Database(
    entities = [User::class, Internship::class, Assignment::class, Submission::class],
    version = 1,
    exportSchema = false
)
@androidx.room.TypeConverters(Converters::class)
abstract class ThulirviDatabase : RoomDatabase() {
    abstract fun thulirviDao(): ThulirviDao

    companion object {
        @Volatile
        private var INSTANCE: ThulirviDatabase? = null

        fun getDatabase(context: Context): ThulirviDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ThulirviDatabase::class.java,
                    "thulirvi_learn.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
