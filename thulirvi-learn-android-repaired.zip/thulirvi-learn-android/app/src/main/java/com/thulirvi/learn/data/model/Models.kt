package com.thulirvi.learn.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
enum class UserRole {
    STUDENT, ADMIN
}

@Serializable
@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val role: UserRole,
    val college: String,
    val regNumber: String,
    val avatarUrl: String? = null
)

@Serializable
@Entity(tableName = "internships")
data class Internship(
    @PrimaryKey val id: String,
    val title: String,
    val domain: String,
    val durationWeeks: Int,
    val level: String,
    val description: String,
    val stipendText: String,
    val mentorName: String,
    val rating: Float
)

@Serializable
@Entity(tableName = "assignments")
data class Assignment(
    @PrimaryKey val id: String,
    val internshipId: String,
    val weekNumber: Int,
    val title: String,
    val problemStatement: String,
    val dueDate: String,
    val maxScore: Int
)

@Serializable
@Entity(tableName = "submissions")
data class Submission(
    @PrimaryKey val id: String,
    val assignmentId: String,
    val studentId: String,
    val githubUrl: String,
    val liveDemoUrl: String? = null,
    val status: String, // PENDING, UNDER_REVIEW, APPROVED, CHANGES_REQUESTED
    val score: Int? = null,
    val mentorFeedback: String? = null,
    val submittedAt: String
)

@Serializable
data class Certificate(
    val credentialId: String,
    val studentName: String,
    val internshipTitle: String,
    val completionDate: String,
    val grade: String,
    val verificationUrl: String
)
