package com.thulirvi.learn.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.thulirvi.learn.R
import com.thulirvi.learn.navigation.Screen

private val tracks = listOf(
    "Python Programming", "Java Programming", "C Programming", "Web Development",
    "Full-Stack Web Development", "Data Science", "AI & Machine Learning", "Cybersecurity",
    "Android App Development", "SQL & Database Management", "Data Analytics", "Cloud Computing"
)

@Composable
private fun BrandHeader() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Image(painter = painterResource(R.drawable.thulirvi_official_logo), contentDescription = "Thulirvi Technologies logo", modifier = Modifier.size(48.dp))
        Column {
            Text("Thulirvi Learn", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Thulirvi Technologies", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            Text("Learn • Build • Grow • Earn", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun PageFrame(title: String, content: @Composable ColumnScope.() -> Unit) {
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            BrandHeader()
            HorizontalDivider()
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
fun LoginScreen(navController: NavHostController) {
    var email by remember { mutableStateOf("") }
    PageFrame("Student login") {
        Text("Use your registered email to continue. Authentication must be connected to the configured backend before production use.")
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email address") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { navController.navigate(Screen.Dashboard.route) }, modifier = Modifier.fillMaxWidth()) { Text("Continue to demo") }
        Text("Demo navigation only — this does not authenticate a real account.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun DashboardScreen(navController: NavHostController) {
    PageFrame("Welcome to your learning hub") {
        Card(shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Virtual internships & self-paced courses", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Browse programmes, then ask the Thulirvi admin team to approve and assign your track.")
            }
        }
        Button(onClick = { navController.navigate(Screen.Internships.route) }, modifier = Modifier.fillMaxWidth()) { Text("Browse programmes") }
        OutlinedButton(onClick = { navController.navigate(Screen.Assignments.route) }, modifier = Modifier.fillMaxWidth()) { Text("My assignments") }
        OutlinedButton(onClick = { navController.navigate(Screen.Certificates.route) }, modifier = Modifier.fillMaxWidth()) { Text("Certificate status") }
        OutlinedButton(onClick = { navController.navigate(Screen.AdminPortal.route) }, modifier = Modifier.fillMaxWidth()) { Text("Admin demo portal") }
        Text("Prototype notice: student login, approval, assignment and progress are not connected to a live backend yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun InternshipListScreen(navController: NavHostController) {
    PageFrame("Programmes") {
        Text("Virtual internship tracks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f, fill = false)) {
            items(tracks) { track ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(track, fontWeight = FontWeight.SemiBold)
                            Text("Proposed track • Admin activation required", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { navController.navigate(Screen.Login.route) }) { Text("Request") }
                    }
                }
            }
        }
        Text("Self-paced courses should be configured separately by the administrator.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun AssignmentScreen(navController: NavHostController) {
    PageFrame("My assignments") {
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("No live assignments loaded", fontWeight = FontWeight.Bold)
                Text("Assignments will appear here after a real student account is approved and linked to a programme and batch.")
            }
        }
        Button(onClick = { navController.navigate(Screen.Internships.route) }) { Text("View programmes") }
    }
}

@Composable
fun CertificateScreen(navController: NavHostController) {
    PageFrame("Certificates") {
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Certificate eligibility", fontWeight = FontWeight.Bold)
                Text("No certificate is issued in this prototype. Eligibility must be calculated from verified module completion, reviewed assignments and admin approval.")
            }
        }
    }
}

@Composable
fun AdminPortalScreen(navController: NavHostController) {
    PageFrame("Admin portal — demo") {
        Text("Production admin access must be protected by backend authentication and role-based permissions.")
        listOf("Review registrations", "Assign programmes and batches", "Manage lessons and assignments", "Review submissions", "Configure certificate criteria").forEach { item ->
            Card(Modifier.fillMaxWidth()) { Text(item, Modifier.padding(14.dp), fontWeight = FontWeight.Medium) }
        }
        Text("These controls are placeholders until backend operations are implemented.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    }
}
