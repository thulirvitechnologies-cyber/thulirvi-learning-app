package com.thulirvi.learn.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.thulirvi.learn.ui.screens.LoginScreen
import com.thulirvi.learn.ui.screens.DashboardScreen
import com.thulirvi.learn.ui.screens.InternshipListScreen
import com.thulirvi.learn.ui.screens.AssignmentScreen
import com.thulirvi.learn.ui.screens.CertificateScreen
import com.thulirvi.learn.ui.screens.AdminPortalScreen

@Composable
fun ThulirviNavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Dashboard.route
    ) {
        composable(Screen.Login.route) {
            LoginScreen(navController = navController)
        }
        composable(Screen.Dashboard.route) {
            DashboardScreen(navController = navController)
        }
        composable(Screen.Internships.route) {
            InternshipListScreen(navController = navController)
        }
        composable(Screen.Assignments.route) {
            AssignmentScreen(navController = navController)
        }
        composable(Screen.Certificates.route) {
            CertificateScreen(navController = navController)
        }
        composable(Screen.AdminPortal.route) {
            AdminPortalScreen(navController = navController)
        }
    }
}
