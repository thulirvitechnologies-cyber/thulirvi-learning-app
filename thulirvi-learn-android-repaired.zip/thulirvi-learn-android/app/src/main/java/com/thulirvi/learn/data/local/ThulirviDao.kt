package com.thulirvi.learn.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.thulirvi.learn.data.model.Assignment
import com.thulirvi.learn.data.model.Internship
import com.thulirvi.learn.data.model.Submission
import com.thulirvi.learn.data.model.User
import kotlinx.coroutines.flow.Flow

@Dao
interface ThulirviDao {
    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: String): User?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Query("SELECT * FROM internships")
    fun getAllInternships(): Flow<List<Internship>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInternships(internships: List<Internship>)

    @Query("SELECT * FROM assignments WHERE internshipId = :internshipId ORDER BY weekNumber ASC")
    fun getAssignmentsForInternship(internshipId: String): Flow<List<Assignment>>

    @Query("SELECT * FROM submissions WHERE studentId = :studentId")
    fun getStudentSubmissions(studentId: String): Flow<List<Submission>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubmission(submission: Submission)
}
