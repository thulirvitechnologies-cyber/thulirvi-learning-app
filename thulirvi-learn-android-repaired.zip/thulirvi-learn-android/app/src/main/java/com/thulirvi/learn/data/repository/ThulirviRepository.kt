package com.thulirvi.learn.data.repository

import com.thulirvi.learn.data.local.ThulirviDao
import com.thulirvi.learn.data.model.Assignment
import com.thulirvi.learn.data.model.Internship
import com.thulirvi.learn.data.model.Submission
import kotlinx.coroutines.flow.Flow

class ThulirviRepository(private val dao: ThulirviDao) {

    fun getInternships(): Flow<List<Internship>> = dao.getAllInternships()

    fun getAssignments(internshipId: String): Flow<List<Assignment>> =
        dao.getAssignmentsForInternship(internshipId)

    fun getSubmissions(studentId: String): Flow<List<Submission>> =
        dao.getStudentSubmissions(studentId)

    suspend fun submitAssignment(submission: Submission) {
        dao.insertSubmission(submission)
    }
}
