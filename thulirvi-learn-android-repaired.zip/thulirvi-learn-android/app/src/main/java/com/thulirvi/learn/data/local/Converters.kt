package com.thulirvi.learn.data.local

import androidx.room.TypeConverter
import com.thulirvi.learn.data.model.UserRole

class Converters {
    @TypeConverter fun fromUserRole(value: UserRole): String = value.name
    @TypeConverter fun toUserRole(value: String): UserRole = UserRole.valueOf(value)
}
